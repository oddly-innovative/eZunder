# Create Next.js configuration files
next_config = '''/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: ['localhost', 'images.unsplash.com'],
  },
  env: {
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
  },
}

module.exports = nextConfig
'''

# TypeScript configuration
tsconfig = {
    "compilerOptions": {
        "target": "es5",
        "lib": ["dom", "dom.iterable", "es6"],
        "allowJs": True,
        "skipLibCheck": True,
        "strict": True,
        "noEmit": True,
        "esModuleInterop": True,
        "module": "esnext",
        "moduleResolution": "bundler",
        "resolveJsonModule": True,
        "isolatedModules": True,
        "jsx": "preserve",
        "incremental": True,
        "plugins": [
            {
                "name": "next"
            }
        ],
        "paths": {
            "@/*": ["./src/*"]
        }
    },
    "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
    "exclude": ["node_modules"]
}

# Tailwind CSS configuration
tailwind_config = '''/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // eZunder Custom Colors
        "neon-green": "#39FF14",
        "forest-teal": "#26FFAE", 
        "dark-forest": "#001E2F",
        "charcoal-black": "#121212",
        "ember-orange": "#FF6F3D",
        "warm-amber": "#FFB347",
        "smoke-gray": "#576975",
        "pure-white": "#FFFFFF"
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      keyframes: {
        "accordion-down": {
          from: { height: 0 },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: 0 },
        },
        "neon-glow": {
          "0%, 100%": { textShadow: "0 0 5px #39FF14, 0 0 10px #39FF14, 0 0 15px #39FF14" },
          "50%": { textShadow: "0 0 10px #39FF14, 0 0 20px #39FF14, 0 0 30px #39FF14" },
        },
        "ember-float": {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-10px)" },
        }
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "neon-glow": "neon-glow 2s ease-in-out infinite",
        "ember-float": "ember-float 3s ease-in-out infinite",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
'''

# PostCSS configuration
postcss_config = '''module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
'''

# Environment variables template
env_example = '''# Database
DATABASE_URL="postgresql://username:password@localhost:5432/ezunder"

# NextAuth.js
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="your-secret-key-here"

# Google OAuth
GOOGLE_CLIENT_ID="your-google-client-id"
GOOGLE_CLIENT_SECRET="your-google-client-secret"

# Google Cloud Platform
GCP_PROJECT_ID="your-gcp-project-id"
GCP_CLIENT_EMAIL="your-service-account-email"
GCP_PRIVATE_KEY="your-service-account-private-key"
VERTEX_AI_LOCATION="us-central1"

# OpenAI (for cover generation)
OPENAI_API_KEY="your-openai-key"

# File Storage
NEXT_PUBLIC_STORAGE_BUCKET="your-gcs-bucket"
'''

# Write configuration files
files_to_create = {
    "ezunder-complete/next.config.js": next_config,
    "ezunder-complete/tailwind.config.js": tailwind_config,
    "ezunder-complete/postcss.config.js": postcss_config,
    "ezunder-complete/.env.example": env_example
}

for file_path, content in files_to_create.items():
    with open(file_path, "w") as f:
        f.write(content)

# Create tsconfig.json
with open("ezunder-complete/tsconfig.json", "w") as f:
    json.dump(tsconfig, f, indent=2)

print("✅ Next.js configuration files created:")
for file_path in files_to_create.keys():
    print(f"   📄 {file_path.split('/')[-1]}")
print("   📄 tsconfig.json")