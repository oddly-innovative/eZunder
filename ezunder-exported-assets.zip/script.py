# Create the complete eZunder Next.js 14 application structure
import os
import json

# Create directory structure
directories = [
    "ezunder-complete",
    "ezunder-complete/src",
    "ezunder-complete/src/app",
    "ezunder-complete/src/app/(auth)",
    "ezunder-complete/src/app/(auth)/login",
    "ezunder-complete/src/app/(auth)/signup",
    "ezunder-complete/src/app/dashboard",
    "ezunder-complete/src/app/editor",
    "ezunder-complete/src/app/export",
    "ezunder-complete/src/app/api",
    "ezunder-complete/src/app/api/auth",
    "ezunder-complete/src/app/api/projects",
    "ezunder-complete/src/app/api/ai",
    "ezunder-complete/src/components",
    "ezunder-complete/src/components/ui",
    "ezunder-complete/src/components/editor",
    "ezunder-complete/src/components/dashboard",
    "ezunder-complete/src/lib",
    "ezunder-complete/src/types",
    "ezunder-complete/public",
    "ezunder-complete/prisma"
]

for directory in directories:
    os.makedirs(directory, exist_ok=True)

print("✅ Directory structure created successfully!")
print(f"📁 Created {len(directories)} directories")