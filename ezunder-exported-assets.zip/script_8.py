# Create dashboard layout and components

# Dashboard layout component
dashboard_layout_tsx = '''import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { DashboardNav } from "@/components/dashboard/dashboard-nav";
import { UserAccountNav } from "@/components/dashboard/user-account-nav";
import { MobileNav } from "@/components/dashboard/mobile-nav";

export const metadata: Metadata = {
  title: "Dashboard | eZunder",
  description: "Manage your eBook projects",
};

interface DashboardLayoutProps {
  children?: React.ReactNode;
}

export default async function DashboardLayout({
  children,
}: DashboardLayoutProps) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex items-center gap-4 md:gap-8">
            <div className="hidden md:flex">
              <div className="flex items-center space-x-2">
                <span className="neon-text text-2xl font-bold">e</span>
                <span className="text-2xl font-bold text-white">Zunder</span>
              </div>
            </div>
            <div className="block md:hidden">
              <MobileNav />
            </div>
          </div>
          <UserAccountNav
            user={{
              name: user.name || "",
              image: user.image || "",
              email: user.email || "",
            }}
          />
        </div>
      </header>
      <div className="container grid flex-1 md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr]">
        <aside className="hidden border-r md:block">
          <DashboardNav />
        </aside>
        <main className="flex-1 overflow-x-hidden p-6">{children}</main>
      </div>
    </div>
  );
}
'''

# Dashboard page
dashboard_page_tsx = '''import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { ProjectCard } from "@/components/dashboard/project-card";
import { Button } from "@/components/ui/button";
import { Plus, FileUp, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { prisma } from "@/lib/prisma";

export const metadata: Metadata = {
  title: "Dashboard | eZunder",
  description: "Manage your eBook projects",
};

export default async function DashboardPage() {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  // Get user projects
  const projects = await prisma.project.findMany({
    where: {
      userId: user.id,
    },
    orderBy: {
      updatedAt: "desc",
    },
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Your Projects</h2>
          <p className="text-muted-foreground">
            Manage and create your eBook projects.
          </p>
        </div>
        <div className="flex flex-col gap-2 md:flex-row md:gap-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search projects..."
              className="w-full bg-background pl-8 md:w-[300px]"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <FileUp className="mr-2 h-4 w-4" />
              Import
            </Button>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              New Project
            </Button>
          </div>
        </div>
      </div>
      
      {projects.length > 0 ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <ProjectCard
              key={project.id}
              project={{
                id: project.id,
                title: project.title,
                description: project.description || "",
                coverImage: project.coverImage,
                updatedAt: project.updatedAt,
              }}
            />
          ))}
          <div className="flex h-full min-h-[220px] flex-col items-center justify-center rounded-xl border border-dashed border-muted-foreground/20 p-8 text-center hover:border-muted-foreground/30 hover:bg-muted/20">
            <div className="mb-3 rounded-full bg-muted/80 p-3">
              <Plus className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-medium">Create New Project</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Start a new eBook from scratch
            </p>
          </div>
        </div>
      ) : (
        <div className="flex min-h-[400px] flex-col items-center justify-center rounded-xl border border-dashed p-8 text-center animate-in fade-in-50">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
            <FileUp className="h-10 w-10 text-muted-foreground" />
          </div>
          <h2 className="mt-6 text-xl font-semibold">No projects yet</h2>
          <p className="mt-2 text-center text-sm text-muted-foreground max-w-sm mx-auto">
            You don't have any projects yet. Create a new project or import an existing manuscript to get started.
          </p>
          <div className="mt-6 flex space-x-4">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create New Project
            </Button>
            <Button variant="outline">
              <FileUp className="mr-2 h-4 w-4" />
              Import
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
'''

# Dashboard nav component
dashboard_nav_tsx = '''import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  FileText,
  Settings,
  HelpCircle,
  Sparkles,
  FileUp,
} from "lucide-react";

interface DashboardNavProps extends React.HTMLAttributes<HTMLDivElement> {}

export function DashboardNav({ className, ...props }: DashboardNavProps) {
  const pathname = usePathname();

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
      variant: "default",
    },
    {
      title: "Projects",
      href: "/dashboard/projects",
      icon: BookOpen,
      variant: "default",
    },
    {
      title: "Templates",
      href: "/dashboard/templates",
      icon: FileText,
      variant: "default",
    },
    {
      title: "AI Assistant",
      href: "/dashboard/ai",
      icon: Sparkles,
      variant: "neon",
    },
    {
      title: "Import",
      href: "/dashboard/import",
      icon: FileUp,
      variant: "default",
    },
    {
      title: "Collaboration",
      href: "/dashboard/collaboration",
      icon: Users,
      variant: "default",
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
      variant: "default",
    },
    {
      title: "Help",
      href: "/dashboard/help",
      icon: HelpCircle,
      variant: "default",
    },
  ];

  return (
    <nav
      className={cn("grid items-start gap-2 p-4", className)}
      {...props}
    >
      {navItems.map((item, index) => {
        const Icon = item.icon;
        return (
          <Link
            key={index}
            href={item.href}
            className={cn(
              "group flex items-center rounded-md px-3 py-2 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-all",
              pathname === item.href ? "bg-accent text-accent-foreground" : "transparent",
              item.variant === "neon" ? "text-neon-green" : "text-foreground/60"
            )}
          >
            <Icon
              className={cn("mr-2 h-4 w-4", 
                item.variant === "neon" ? "text-neon-green" : "text-foreground/60",
                pathname === item.href && item.variant !== "neon" ? "text-accent-foreground" : ""
              )}
            />
            <span>{item.title}</span>
          </Link>
        );
      })}
    </nav>
  );
}
'''

# Project card component
project_card_tsx = '''import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { formatDate } from "@/lib/utils";
import { MoreVertical, BookOpen } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

interface ProjectCardProps {
  project: {
    id: string;
    title: string;
    description: string;
    coverImage: string | null;
    updatedAt: Date;
  };
}

export function ProjectCard({ project }: ProjectCardProps) {
  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <CardHeader className="p-0">
        <div className="relative h-[160px] w-full overflow-hidden">
          {project.coverImage ? (
            <img
              src={project.coverImage}
              alt={project.title}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="h-full w-full bg-gradient-to-br from-forest-teal/20 to-neon-green/20 flex items-center justify-center">
              <BookOpen className="h-12 w-12 text-forest-teal" />
            </div>
          )}
          <div className="absolute right-2 top-2">
            <Button variant="ghost" size="icon" className="h-8 w-8 bg-background/80 backdrop-blur-sm rounded-full">
              <MoreVertical className="h-4 w-4" />
              <span className="sr-only">More options</span>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div>
          <Link href={`/editor/${project.id}`}>
            <h3 className="font-semibold line-clamp-1 hover:text-neon-green transition-colors">
              {project.title}
            </h3>
          </Link>
          <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
            {project.description || "No description provided."}
          </p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 text-xs text-muted-foreground">
        <p>Last updated: {formatDate(project.updatedAt)}</p>
      </CardFooter>
    </Card>
  );
}
'''

# User account navigation
user_account_nav_tsx = '''import { CreditCard, LogOut, Settings, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { getInitials } from "@/lib/utils";

interface UserAccountNavProps extends React.HTMLAttributes<HTMLDivElement> {
  user: {
    name?: string;
    image?: string;
    email?: string;
  };
}

export function UserAccountNav({ user }: UserAccountNavProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="relative h-8 w-8 rounded-full"
        >
          <Avatar className="h-9 w-9">
            <AvatarImage
              src={user.image ?? ""}
              alt={user.name ?? ""}
              className="object-cover"
            />
            <AvatarFallback className="bg-forest-teal/30 text-forest-teal">
              {user.name ? getInitials(user.name) : "U"}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">
              {user.name}
            </p>
            <p className="text-xs leading-none text-muted-foreground">
              {user.email}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem>
            <User className="mr-2 h-4 w-4" />
            <span>Profile</span>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <CreditCard className="mr-2 h-4 w-4" />
            <span>Billing</span>
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
'''

# Mobile navigation
mobile_nav_tsx = '''import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu } from "lucide-react";
import { cn } from "@/lib/utils";
import { Icons } from "@/components/icons";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  FileText,
  Settings,
  HelpCircle,
  Sparkles,
  FileUp,
} from "lucide-react";

export function MobileNav() {
  const [open, setOpen] = React.useState(false);
  const pathname = usePathname();

  const routes = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
      variant: "default",
    },
    {
      title: "Projects",
      href: "/dashboard/projects",
      icon: BookOpen,
      variant: "default",
    },
    {
      title: "Templates",
      href: "/dashboard/templates",
      icon: FileText,
      variant: "default",
    },
    {
      title: "AI Assistant",
      href: "/dashboard/ai",
      icon: Sparkles,
      variant: "neon",
    },
    {
      title: "Import",
      href: "/dashboard/import",
      icon: FileUp,
      variant: "default",
    },
    {
      title: "Collaboration",
      href: "/dashboard/collaboration",
      icon: Users,
      variant: "default",
    },
    {
      title: "Settings",
      href: "/dashboard/settings",
      icon: Settings,
      variant: "default",
    },
    {
      title: "Help",
      href: "/dashboard/help",
      icon: HelpCircle,
      variant: "default",
    },
  ];

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden"
        >
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle Menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="pr-0">
        <div className="px-7">
          <Link href="/" className="flex items-center" onClick={() => setOpen(false)}>
            <Icons.logo className="h-6 w-6 mr-2" />
            <span className="font-bold">
              <span className="text-neon-green">e</span>Zunder
            </span>
          </Link>
        </div>
        <nav className="grid gap-2 text-lg font-medium px-4 pt-8">
          {routes.map((route, i) => {
            const Icon = route.icon;
            return (
              <Link
                key={i}
                href={route.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-2 py-2 px-3 rounded-md",
                  pathname === route.href
                    ? "bg-accent text-accent-foreground"
                    : "hover:bg-accent/50 hover:text-accent-foreground",
                  route.variant === "neon" ? "text-neon-green" : ""
                )}
              >
                <Icon className={cn("h-4 w-4", 
                  route.variant === "neon" ? "text-neon-green" : "",
                  pathname === route.href && route.variant !== "neon" ? "text-accent-foreground" : ""
                )} />
                <span>{route.title}</span>
              </Link>
            );
          })}
        </nav>
      </SheetContent>
    </Sheet>
  );
}
'''

# Session utility
session_ts = '''import { getServerSession } from "next-auth/next";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";

export async function getSession() {
  return await getServerSession(authOptions);
}

export async function getCurrentUser() {
  const session = await getSession();
  
  return session?.user;
}
'''

# Create the dashboard components
dashboard_components = {
    "ezunder-complete/src/app/dashboard/layout.tsx": dashboard_layout_tsx,
    "ezunder-complete/src/app/dashboard/page.tsx": dashboard_page_tsx,
    "ezunder-complete/src/components/dashboard/dashboard-nav.tsx": dashboard_nav_tsx,
    "ezunder-complete/src/components/dashboard/project-card.tsx": project_card_tsx,
    "ezunder-complete/src/components/dashboard/user-account-nav.tsx": user_account_nav_tsx,
    "ezunder-complete/src/components/dashboard/mobile-nav.tsx": mobile_nav_tsx,
    "ezunder-complete/src/lib/session.ts": session_ts,
}

for file_path, content in dashboard_components.items():
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w") as f:
        f.write(content)

print("✅ Dashboard components created:")
for file_path in dashboard_components.keys():
    print(f"   📄 {file_path.split('/')[-1]}")