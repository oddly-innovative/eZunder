# Create landing page components

# Hero section component
hero_section_tsx = '''import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, BookOpen, FileType } from "lucide-react";
import Link from "next/link";

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-charcoal-black to-dark-forest">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%2339FF14" fill-opacity="0.05"%3E%3Ccircle cx="30" cy="30" r="1"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
        {/* Ember particles floating */}
        <div className="absolute top-1/4 left-1/4 ember-particle"></div>
        <div className="absolute top-1/3 right-1/3 ember-particle"></div>
        <div className="absolute bottom-1/4 left-1/3 ember-particle"></div>
        <div className="absolute bottom-1/3 right-1/4 ember-particle"></div>
        <div className="absolute top-1/2 left-1/2 ember-particle"></div>
      </div>
      <div className="container relative px-6 py-32 sm:py-40 lg:py-48">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-8 flex justify-center">
            <div className="relative">
              <div className="flex items-center space-x-3 rounded-full bg-neon-green/10 px-6 py-3 text-sm ring-1 ring-neon-green/20">
                <Sparkles className="h-4 w-4 text-neon-green" />
                <span className="text-neon-green font-medium">AI-Powered eBook Formatting</span>
              </div>
            </div>
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl">
            Transform your manuscripts into{" "}
            <span className="neon-text">professional</span> eBooks
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-smoke-gray">
            eZunder combines cutting-edge AI technology with professional eBook formatting tools. 
            Create stunning, format-perfect eBooks that captivate readers across all platforms.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Link href="/signup" passHref>
              <Button 
                size="lg" 
                className="bg-neon-green hover:bg-neon-green/90 text-dark-forest font-semibold shadow-[0_0_20px_rgba(57,255,20,0.3)] hover:shadow-[0_0_30px_rgba(57,255,20,0.5)] transition-all duration-300"
              >
                Start Creating Free
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/demo" passHref>
              <Button variant="outline" size="lg" className="border-forest-teal text-forest-teal hover:bg-forest-teal hover:text-dark-forest">
                Watch Demo
                <BookOpen className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-forest-teal/20 p-3 ring-1 ring-forest-teal/30">
                <FileType className="h-6 w-6 text-forest-teal" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">Multi-Format Support</h3>
              <p className="mt-2 text-sm text-smoke-gray text-center">
                Import DOCX, TXT, EPUB files. Export to all major eBook formats.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-warm-amber/20 p-3 ring-1 ring-warm-amber/30">
                <Sparkles className="h-6 w-6 text-warm-amber" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">AI Typography</h3>
              <p className="mt-2 text-sm text-smoke-gray text-center">
                Smart font pairing and layout suggestions based on your content.
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="rounded-full bg-ember-orange/20 p-3 ring-1 ring-ember-orange/30">
                <BookOpen className="h-6 w-6 text-ember-orange" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-white">Professional Output</h3>
              <p className="mt-2 text-sm text-smoke-gray text-center">
                Create eBooks that rival traditional publishing quality.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
'''

# Features section
features_section_tsx = '''import { CheckCircle, Zap, Users, BookOpen, Palette, Cloud } from "lucide-react";

const features = [
  {
    name: "AI-Powered Content Analysis",
    description: "Intelligent genre detection, mood analysis, and typography recommendations tailored to your manuscript.",
    icon: Zap,
    color: "text-neon-green",
    bg: "bg-neon-green/10",
  },
  {
    name: "Real-time Collaboration",
    description: "Work with editors, designers, and beta readers in real-time with version control and comments.",
    icon: Users,
    color: "text-forest-teal",
    bg: "bg-forest-teal/10",
  },
  {
    name: "Multi-Device Preview",
    description: "See exactly how your eBook will look on Kindle, iPad, mobile devices, and more.",
    icon: BookOpen,
    color: "text-warm-amber",
    bg: "bg-warm-amber/10",
  },
  {
    name: "Professional Typography",
    description: "Advanced typography controls with context-aware font recommendations and spacing optimization.",
    icon: Palette,
    color: "text-ember-orange",
    bg: "bg-ember-orange/10",
  },
  {
    name: "Smart Export Engine",
    description: "Export to EPUB, MOBI, PDF with format-specific optimizations and validation.",
    icon: Cloud,
    color: "text-forest-teal",
    bg: "bg-forest-teal/10",
  },
  {
    name: "Quality Assurance",
    description: "Automated checks for accessibility, formatting consistency, and industry standards compliance.",
    icon: CheckCircle,
    color: "text-neon-green",
    bg: "bg-neon-green/10",
  },
];

export default function FeaturesSection() {
  return (
    <section className="py-24 bg-background">
      <div className="container px-6 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-4">
            Everything you need to create <span className="forest-text">amazing</span> eBooks
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            From AI-powered content analysis to professional-grade export tools, 
            eZunder provides a complete publishing workflow.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.name}
              className="relative p-8 bg-card rounded-xl border hover:shadow-lg transition-all duration-300 hover:border-forest-teal/30"
            >
              <div className={`inline-flex rounded-lg p-3 ${feature.bg} ring-1 ring-opacity-30`}>
                <feature.icon className={`h-6 w-6 ${feature.color}`} aria-hidden="true" />
              </div>
              <h3 className="mt-6 text-xl font-semibold text-foreground">{feature.name}</h3>
              <p className="mt-4 text-muted-foreground leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
'''

# Pricing section
pricing_section_tsx = '''import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Star, Zap } from "lucide-react";
import Link from "next/link";

const pricingTiers = [
  {
    name: "Starter",
    description: "Perfect for individual authors and new writers",
    price: "$0",
    period: "forever",
    features: [
      "3 projects",
      "Basic AI suggestions",
      "EPUB export",
      "Community support",
      "5GB storage",
    ],
    buttonText: "Get Started",
    buttonVariant: "outline" as const,
    popular: false,
  },
  {
    name: "Professional",
    description: "For serious authors and small publishing teams",
    price: "$19",
    period: "month",
    features: [
      "Unlimited projects",
      "Advanced AI analysis", 
      "All export formats",
      "Priority support",
      "50GB storage",
      "Real-time collaboration",
      "Custom branding",
    ],
    buttonText: "Start Free Trial",
    buttonVariant: "default" as const,
    popular: true,
  },
  {
    name: "Enterprise",
    description: "For publishing houses and large teams",
    price: "$99",
    period: "month",
    features: [
      "Everything in Professional",
      "Advanced analytics",
      "API access",
      "Custom integrations",
      "500GB storage",
      "Dedicated support",
      "Training sessions",
      "SLA guarantee",
    ],
    buttonText: "Contact Sales",
    buttonVariant: "secondary" as const,
    popular: false,
  },
];

export default function PricingSection() {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container px-6 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl lg:text-5xl mb-4">
            Choose your <span className="amber-text">publishing</span> plan
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Start free and scale as your publishing needs grow. All plans include core formatting features.
          </p>
        </div>
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {pricingTiers.map((tier) => (
            <Card 
              key={tier.name} 
              className={`relative ${
                tier.popular 
                  ? "border-neon-green shadow-[0_0_30px_rgba(57,255,20,0.2)] scale-105" 
                  : "border-border"
              }`}
            >
              {tier.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-neon-green text-dark-forest px-4 py-1 rounded-full text-sm font-medium flex items-center">
                    <Star className="h-4 w-4 mr-1" />
                    Most Popular
                  </span>
                </div>
              )}
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl font-bold">{tier.name}</CardTitle>
                <CardDescription className="text-muted-foreground">
                  {tier.description}
                </CardDescription>
                <div className="mt-6">
                  <span className="text-4xl font-bold">{tier.price}</span>
                  <span className="text-muted-foreground">/{tier.period}</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-center">
                      <Check className="h-4 w-4 text-neon-green mr-3 flex-shrink-0" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/signup" className="w-full">
                  <Button 
                    variant={tier.buttonVariant} 
                    className="w-full"
                    size="lg"
                  >
                    {tier.buttonText}
                    {tier.popular && <Zap className="ml-2 h-4 w-4" />}
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
'''

# Footer component
footer_tsx = '''import Link from "next/link";
import { Icons } from "@/components/icons";

export default function Footer() {
  return (
    <footer className="bg-dark-forest border-t border-forest-teal/20">
      <div className="container px-6 py-12 mx-auto">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Icons.logo className="h-6 w-6 text-neon-green" />
              <span className="font-bold text-xl text-white">
                <span className="text-neon-green">e</span>Zunder
              </span>
            </div>
            <p className="text-smoke-gray text-sm">
              AI-powered eBook formatting platform that helps authors create professional, 
              beautifully designed eBooks with ease.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-smoke-gray hover:text-neon-green transition-colors">
                <Icons.twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-smoke-gray hover:text-neon-green transition-colors">
                <Icons.gitHub className="h-5 w-5" />
              </Link>
            </div>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Product</h3>
            <ul className="space-y-2">
              <li><Link href="/features" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Features</Link></li>
              <li><Link href="/pricing" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Pricing</Link></li>
              <li><Link href="/templates" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Templates</Link></li>
              <li><Link href="/integrations" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Integrations</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><Link href="/docs" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Documentation</Link></li>
              <li><Link href="/guides" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Guides</Link></li>
              <li><Link href="/blog" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Blog</Link></li>
              <li><Link href="/support" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Support</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-white mb-4">Company</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">About</Link></li>
              <li><Link href="/careers" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Careers</Link></li>
              <li><Link href="/privacy" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Privacy</Link></li>
              <li><Link href="/terms" className="text-smoke-gray hover:text-forest-teal transition-colors text-sm">Terms</Link></li>
            </ul>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-forest-teal/20">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-smoke-gray text-sm">
              © 2025 eZunder. All rights reserved.
            </p>
            <p className="text-smoke-gray text-sm mt-4 md:mt-0">
              Built with ❤️ for authors everywhere
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
'''

# Create landing page components
landing_components = {
    "ezunder-complete/src/components/landing/hero-section.tsx": hero_section_tsx,
    "ezunder-complete/src/components/landing/features-section.tsx": features_section_tsx,
    "ezunder-complete/src/components/landing/pricing-section.tsx": pricing_section_tsx,
    "ezunder-complete/src/components/landing/footer.tsx": footer_tsx,
}

for file_path, content in landing_components.items():
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w") as f:
        f.write(content)

print("✅ Landing page components created:")
for file_path in landing_components.keys():
    print(f"   📄 {file_path.split('/')[-1]}")

# Create AI services based on the uploaded specifications
ai_services_ts = '''// AI Services - Based on eZunder technical specifications
import { VertexAI } from "@google-cloud/vertexai";
import { GoogleAuth } from "google-auth-library";

// Mock AI service for demo purposes (replace with actual Vertex AI in production)
export class ContentAnalysisService {
  private mockAnalysisResults = {
    genre: {
      primaryGenre: "Science Fiction",
      subGenre: "Cyberpunk",
      confidence: 0.89,
      themes: ["technology", "artificial intelligence", "dystopia"],
      mood: "suspenseful",
      targetAudience: "adult"
    },
    style: {
      averageSentenceLength: 18.5,
      vocabularyComplexity: "intermediate",
      toneAnalysis: "analytical",
      readingLevel: "grade-12"
    },
    readability: {
      gradeLevel: 12,
      readingEase: 65,
      avgWordsPerSentence: 18.5
    },
    grammar: {
      overallScore: 92,
      errors: [
        {
          type: "style",
          text: "This sentence could be shorter",
          suggestion: "Consider breaking into two sentences",
          position: { start: 150, end: 185 }
        }
      ]
    }
  };

  async analyzeManuscript(content: string, metadata: any) {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Return mock analysis (in production, this would call Vertex AI)
    return this.mockAnalysisResults;
  }

  async generateRecommendations(content: string, metadata: any) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      typography: {
        heading: {
          font: "Inter SemiBold",
          size: "28px",
          lineHeight: "1.2"
        },
        body: {
          font: "Inter Regular",
          size: "16px", 
          lineHeight: "1.5"
        }
      },
      layout: {
        margins: "standard",
        spacing: "comfortable",
        alignment: "justified"
      },
      suggestions: [
        "Consider using shorter paragraphs for better readability",
        "Add more white space between chapters",
        "Inconsistent dialogue formatting detected"
      ]
    };
  }
}

export class TypographyService {
  async recommendTypography(analysisResults: any, userPreferences: any) {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      fonts: {
        heading: {
          family: "Inter",
          weight: "600",
          size: "28px",
          confidence: 0.92
        },
        body: {
          family: "Inter",
          weight: "400", 
          size: "16px",
          lineHeight: "1.5",
          confidence: 0.88
        }
      },
      layout: {
        margins: { top: "2rem", bottom: "2rem", left: "1.5rem", right: "1.5rem" },
        spacing: { paragraph: "1rem", chapter: "3rem" }
      },
      pairingRationale: "Clean, modern serif complements the technical content while maintaining readability."
    };
  }

  async optimizeForDevice(typography: any, device: string) {
    const deviceOptimizations = {
      kindle: { baseSize: 14, maxLineLength: 65 },
      ipad: { baseSize: 16, maxLineLength: 70 }, 
      mobile: { baseSize: 18, maxLineLength: 45 }
    };
    
    return {
      ...typography,
      deviceSpecific: deviceOptimizations[device as keyof typeof deviceOptimizations]
    };
  }
}

export class CoverGenerationService {
  async generateBookCover(bookData: any, analysisResults: any) {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return {
      imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop",
      style: {
        name: "Modern Minimalist",
        description: "Clean typography with abstract geometric elements"
      },
      designElements: {
        colorPalette: ["#39FF14", "#001E2F", "#FFFFFF"],
        typography: "Inter Bold for title, Inter Regular for author"
      },
      confidence: 0.85
    };
  }

  async createDesignBrief(bookData: any, analysis: any) {
    return {
      visualThemes: ["technology", "forest", "mystery"],
      colorPalette: ["#39FF14", "#26FFAE", "#001E2F"],
      mood: "suspenseful",
      composition: "vertical",
      symbolElements: ["circuit patterns", "tree silhouettes"]
    };
  }
}
'''

with open("ezunder-complete/src/lib/ai-services.ts", "w") as f:
    f.write(ai_services_ts)

print("✅ AI services created based on technical specifications")