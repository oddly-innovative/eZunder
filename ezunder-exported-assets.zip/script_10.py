# Create the main editor interface - the three-panel layout as specified

# Editor layout component
editor_layout_tsx = '''import { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { EditorProvider } from "@/components/editor/editor-provider";

export const metadata: Metadata = {
  title: "Editor | eZunder",
  description: "AI-powered eBook editor",
};

interface EditorLayoutProps {
  children: React.ReactNode;
  params: { projectId: string };
}

export default async function EditorLayout({
  children,
  params,
}: EditorLayoutProps) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  return (
    <EditorProvider projectId={params.projectId}>
      <div className="h-screen overflow-hidden bg-background">
        {children}
      </div>
    </EditorProvider>
  );
}
'''

# Editor page component
editor_page_tsx = '''import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/session";
import { prisma } from "@/lib/prisma";
import { EditorInterface } from "@/components/editor/editor-interface";

interface EditorPageProps {
  params: { projectId: string };
}

export default async function EditorPage({ params }: EditorPageProps) {
  const user = await getCurrentUser();

  if (!user) {
    redirect("/login");
  }

  const project = await prisma.project.findFirst({
    where: {
      id: params.projectId,
      userId: user.id,
    },
    include: {
      chapters: {
        orderBy: { orderIndex: "asc" },
      },
    },
  });

  if (!project) {
    redirect("/dashboard");
  }

  return (
    <EditorInterface 
      project={project}
      user={user}
    />
  );
}
'''

# Editor provider component
editor_provider_tsx = '''"use client";

import { createContext, useContext, useReducer, ReactNode } from "react";
import { EditorState, EditorTools, ProjectStats } from "@/types";

interface EditorContextType {
  state: EditorState;
  tools: EditorTools;
  stats: ProjectStats;
  updateContent: (content: string) => void;
  toggleFocusMode: () => void;
  setPreviewMode: (mode: "none" | "split" | "full") => void;
  setActivePanel: (panel: "navigation" | "editor" | "properties") => void;
  updateTools: (tools: Partial<EditorTools>) => void;
  saveProject: () => Promise<void>;
}

const EditorContext = createContext<EditorContextType | undefined>(undefined);

interface EditorState {
  content: string;
  selection: { start: number; end: number };
  focusMode: boolean;
  previewMode: "none" | "split" | "full";
  activePanel: "navigation" | "editor" | "properties";
  isLoading: boolean;
  lastSaved: Date | null;
}

interface EditorAction {
  type: 
    | "UPDATE_CONTENT"
    | "TOGGLE_FOCUS_MODE"
    | "SET_PREVIEW_MODE"
    | "SET_ACTIVE_PANEL"
    | "UPDATE_SELECTION"
    | "SET_LOADING"
    | "SET_LAST_SAVED";
  payload?: any;
}

const initialState: EditorState = {
  content: "",
  selection: { start: 0, end: 0 },
  focusMode: false,
  previewMode: "none",
  activePanel: "editor",
  isLoading: false,
  lastSaved: null,
};

const initialTools: EditorTools = {
  bold: false,
  italic: false,
  underline: false,
  alignment: "left",
  fontSize: 16,
  fontFamily: "Inter",
};

const initialStats: ProjectStats = {
  wordCount: 0,
  characterCount: 0,
  pageCount: 0,
  readingTime: 0,
  chaptersCount: 0,
};

function editorReducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case "UPDATE_CONTENT":
      return { ...state, content: action.payload };
    case "TOGGLE_FOCUS_MODE":
      return { ...state, focusMode: !state.focusMode };
    case "SET_PREVIEW_MODE":
      return { ...state, previewMode: action.payload };
    case "SET_ACTIVE_PANEL":
      return { ...state, activePanel: action.payload };
    case "UPDATE_SELECTION":
      return { ...state, selection: action.payload };
    case "SET_LOADING":
      return { ...state, isLoading: action.payload };
    case "SET_LAST_SAVED":
      return { ...state, lastSaved: action.payload };
    default:
      return state;
  }
}

interface EditorProviderProps {
  children: ReactNode;
  projectId: string;
}

export function EditorProvider({ children, projectId }: EditorProviderProps) {
  const [state, dispatch] = useReducer(editorReducer, initialState);

  const updateContent = (content: string) => {
    dispatch({ type: "UPDATE_CONTENT", payload: content });
  };

  const toggleFocusMode = () => {
    dispatch({ type: "TOGGLE_FOCUS_MODE" });
  };

  const setPreviewMode = (mode: "none" | "split" | "full") => {
    dispatch({ type: "SET_PREVIEW_MODE", payload: mode });
  };

  const setActivePanel = (panel: "navigation" | "editor" | "properties") => {
    dispatch({ type: "SET_ACTIVE_PANEL", payload: panel });
  };

  const updateTools = (tools: Partial<EditorTools>) => {
    // Tools state would be managed here
  };

  const saveProject = async () => {
    dispatch({ type: "SET_LOADING", payload: true });
    try {
      // Save project content via API
      await fetch(`/api/projects/${projectId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: state.content }),
      });
      dispatch({ type: "SET_LAST_SAVED", payload: new Date() });
    } catch (error) {
      console.error("Failed to save project:", error);
    } finally {
      dispatch({ type: "SET_LOADING", payload: false });
    }
  };

  const value: EditorContextType = {
    state,
    tools: initialTools,
    stats: initialStats,
    updateContent,
    toggleFocusMode,
    setPreviewMode,
    setActivePanel,
    updateTools,
    saveProject,
  };

  return (
    <EditorContext.Provider value={value}>
      {children}
    </EditorContext.Provider>
  );
}

export function useEditor() {
  const context = useContext(EditorContext);
  if (!context) {
    throw new Error("useEditor must be used within an EditorProvider");
  }
  return context;
}
'''

# Main editor interface component
editor_interface_tsx = '''"use client";

import { useState } from "react";
import { Project, Chapter, User } from "@/types";
import { EditorHeader } from "@/components/editor/editor-header";
import { NavigationPanel } from "@/components/editor/navigation-panel";
import { EditorCanvas } from "@/components/editor/editor-canvas";
import { PropertiesPanel } from "@/components/editor/properties-panel";
import { useEditor } from "@/components/editor/editor-provider";
import { cn } from "@/lib/utils";

interface EditorInterfaceProps {
  project: Project & { chapters: Chapter[] };
  user: User;
}

export function EditorInterface({ project, user }: EditorInterfaceProps) {
  const { state } = useEditor();
  const [activeChapter, setActiveChapter] = useState<Chapter | null>(
    project.chapters[0] || null
  );

  return (
    <div className="h-screen flex flex-col bg-dark-forest">
      <EditorHeader 
        project={project} 
        user={user}
        activeChapter={activeChapter}
      />
      
      <div className={cn(
        "flex-1 grid transition-all duration-300",
        state.focusMode 
          ? "grid-cols-1" 
          : state.previewMode === "split"
          ? "grid-cols-[280px_1fr_1fr_320px]"
          : "grid-cols-[280px_1fr_320px]"
      )}>
        {/* Left Panel - Navigation */}
        {!state.focusMode && (
          <NavigationPanel
            chapters={project.chapters}
            activeChapter={activeChapter}
            onChapterSelect={setActiveChapter}
            projectId={project.id}
          />
        )}

        {/* Center Panel - Editor */}
        <EditorCanvas
          chapter={activeChapter}
          project={project}
          className={cn(
            state.focusMode && "max-w-4xl mx-auto px-8"
          )}
        />

        {/* Preview Panel - Only in split mode */}
        {state.previewMode === "split" && !state.focusMode && (
          <div className="border-l border-forest-teal/20 bg-charcoal-black/50">
            <div className="p-4 border-b border-forest-teal/20">
              <h3 className="font-medium text-forest-teal">Live Preview</h3>
            </div>
            <div className="p-4 prose prose-invert max-w-none">
              <div dangerouslySetInnerHTML={{ __html: state.content }} />
            </div>
          </div>
        )}

        {/* Right Panel - Properties */}
        {!state.focusMode && (
          <PropertiesPanel
            chapter={activeChapter}
            project={project}
          />
        )}
      </div>
    </div>
  );
}
'''

# Editor header component
editor_header_tsx = '''"use client";

import { useState } from "react";
import { Project, Chapter, User } from "@/types";
import { Button } from "@/components/ui/button";
import { useEditor } from "@/components/editor/editor-provider";
import {
  Save,
  Eye,
  EyeOff,
  Focus,
  Columns,
  Settings,
  Share,
  Download,
  ArrowLeft,
} from "lucide-react";
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";

interface EditorHeaderProps {
  project: Project;
  user: User;
  activeChapter: Chapter | null;
}

export function EditorHeader({ project, user, activeChapter }: EditorHeaderProps) {
  const { state, toggleFocusMode, setPreviewMode, saveProject } = useEditor();
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await saveProject();
    setIsSaving(false);
  };

  const togglePreview = () => {
    setPreviewMode(state.previewMode === "split" ? "none" : "split");
  };

  return (
    <header className="h-16 bg-dark-forest border-b border-forest-teal/20 flex items-center justify-between px-6">
      <div className="flex items-center space-x-4">
        <Link href="/dashboard">
          <Button variant="ghost" size="icon" className="text-smoke-gray hover:text-white">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        
        <div className="flex items-center space-x-2">
          <span className="neon-text text-xl font-bold">e</span>
          <span className="text-xl font-bold text-white">Zunder</span>
        </div>
        
        <div className="h-6 w-px bg-forest-teal/30" />
        
        <div>
          <h1 className="font-semibold text-white">{project.title}</h1>
          {activeChapter && (
            <p className="text-sm text-smoke-gray">
              {activeChapter.title}
            </p>
          )}
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleFocusMode}
          className={state.focusMode ? "text-warm-amber" : "text-smoke-gray"}
        >
          <Focus className="h-4 w-4 mr-2" />
          Focus
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={togglePreview}
          className={state.previewMode === "split" ? "text-forest-teal" : "text-smoke-gray"}
        >
          <Columns className="h-4 w-4 mr-2" />
          Preview
        </Button>

        <div className="h-6 w-px bg-forest-teal/30" />

        <Button variant="ghost" size="sm" className="text-smoke-gray">
          <Share className="h-4 w-4 mr-2" />
          Share
        </Button>

        <Button variant="ghost" size="sm" className="text-smoke-gray">
          <Download className="h-4 w-4 mr-2" />
          Export
        </Button>

        <Button
          variant="default"
          size="sm"
          onClick={handleSave}
          disabled={isSaving}
          className="bg-neon-green hover:bg-neon-green/90 text-dark-forest"
        >
          <Save className="h-4 w-4 mr-2" />
          {isSaving ? "Saving..." : "Save"}
        </Button>

        <Avatar className="h-8 w-8">
          <AvatarImage src={user.image || ""} alt={user.name || ""} />
          <AvatarFallback className="bg-forest-teal/30 text-forest-teal">
            {getInitials(user.name || "User")}
          </AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
}
'''

# Create the editor components
editor_components = {
    "ezunder-complete/src/app/editor/[projectId]/layout.tsx": editor_layout_tsx,
    "ezunder-complete/src/app/editor/[projectId]/page.tsx": editor_page_tsx,
    "ezunder-complete/src/components/editor/editor-provider.tsx": editor_provider_tsx,
    "ezunder-complete/src/components/editor/editor-interface.tsx": editor_interface_tsx,
    "ezunder-complete/src/components/editor/editor-header.tsx": editor_header_tsx,
}

for file_path, content in editor_components.items():
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w") as f:
        f.write(content)

print("✅ Main editor interface components created:")
for file_path in editor_components.keys():
    print(f"   📄 {file_path.split('/')[-1]}")