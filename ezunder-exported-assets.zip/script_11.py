# Create the remaining editor components

# Navigation panel (left panel)
navigation_panel_tsx = '''"use client";

import { useState } from "react";
import { Chapter } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ChevronDown,
  ChevronRight,
  Plus,
  MoreVertical,
  FileText,
  Search,
  BookOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NavigationPanelProps {
  chapters: Chapter[];
  activeChapter: Chapter | null;
  onChapterSelect: (chapter: Chapter) => void;
  projectId: string;
}

export function NavigationPanel({
  chapters,
  activeChapter,
  onChapterSelect,
  projectId,
}: NavigationPanelProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set());

  const toggleChapterExpansion = (chapterId: string) => {
    const newExpanded = new Set(expandedChapters);
    if (newExpanded.has(chapterId)) {
      newExpanded.delete(chapterId);
    } else {
      newExpanded.add(chapterId);
    }
    setExpandedChapters(newExpanded);
  };

  const filteredChapters = chapters.filter((chapter) =>
    chapter.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-dark-forest border-r border-forest-teal/20 flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-forest-teal/20">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-white flex items-center">
            <BookOpen className="h-4 w-4 mr-2 text-forest-teal" />
            Manuscript
          </h2>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-smoke-gray">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-smoke-gray" />
          <Input
            placeholder="Search chapters..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-8 bg-charcoal-black border-forest-teal/20 text-white placeholder:text-smoke-gray"
          />
        </div>
      </div>

      {/* Chapter Tree */}
      <div className="flex-1 overflow-auto p-2">
        <div className="space-y-1">
          {filteredChapters.length > 0 ? (
            filteredChapters.map((chapter, index) => (
              <div
                key={chapter.id}
                className={cn(
                  "group rounded-md transition-all",
                  activeChapter?.id === chapter.id
                    ? "bg-forest-teal/20 text-forest-teal"
                    : "hover:bg-charcoal-black/50"
                )}
              >
                <div
                  className="flex items-center px-3 py-2 cursor-pointer"
                  onClick={() => onChapterSelect(chapter)}
                >
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleChapterExpansion(chapter.id);
                    }}
                    className="mr-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    {expandedChapters.has(chapter.id) ? (
                      <ChevronDown className="h-3 w-3" />
                    ) : (
                      <ChevronRight className="h-3 w-3" />
                    )}
                  </button>
                  
                  <FileText className="h-4 w-4 mr-2 text-smoke-gray" />
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {chapter.title || `Chapter ${index + 1}`}
                    </p>
                    <p className="text-xs text-smoke-gray">
                      {chapter.content ? `${chapter.content.split(" ").length} words` : "Empty"}
                    </p>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <MoreVertical className="h-3 w-3" />
                  </Button>
                </div>
                
                {/* Nested content preview */}
                {expandedChapters.has(chapter.id) && chapter.content && (
                  <div className="pl-12 pr-3 pb-2">
                    <p className="text-xs text-smoke-gray/70 line-clamp-2">
                      {chapter.content.substring(0, 100)}...
                    </p>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <FileText className="h-8 w-8 text-smoke-gray mx-auto mb-2" />
              <p className="text-sm text-smoke-gray">No chapters found</p>
              <Button variant="ghost" size="sm" className="mt-2 text-forest-teal">
                <Plus className="h-4 w-4 mr-2" />
                Add Chapter
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-forest-teal/20">
        <div className="text-xs text-smoke-gray">
          <div className="flex justify-between">
            <span>{chapters.length} chapters</span>
            <span>
              {chapters.reduce((acc, ch) => acc + (ch.content?.split(" ").length || 0), 0)} words
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
'''

# Editor canvas (center panel)
editor_canvas_tsx = '''"use client";

import { useEffect, useRef, useState } from "react";
import { Chapter, Project } from "@/types";
import { useEditor } from "@/components/editor/editor-provider";
import { EditorToolbar } from "@/components/editor/editor-toolbar";
import { cn } from "@/lib/utils";

interface EditorCanvasProps {
  chapter: Chapter | null;
  project: Project;
  className?: string;
}

export function EditorCanvas({ chapter, project, className }: EditorCanvasProps) {
  const { state, updateContent } = useEditor();
  const editorRef = useRef<HTMLDivElement>(null);
  const [content, setContent] = useState(chapter?.content || "");
  const [showToolbar, setShowToolbar] = useState(false);

  useEffect(() => {
    if (chapter?.content !== undefined) {
      setContent(chapter.content);
    }
  }, [chapter?.id]);

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    updateContent(newContent);
  };

  const handleSelection = () => {
    const selection = window.getSelection();
    if (selection && !selection.isCollapsed) {
      setShowToolbar(true);
    } else {
      setShowToolbar(false);
    }
  };

  return (
    <div className={cn("relative flex flex-col h-full", className)}>
      {/* Chapter Header */}
      {chapter && !state.focusMode && (
        <div className="px-6 py-4 border-b border-forest-teal/10">
          <h2 className="text-xl font-semibold text-white mb-1">
            {chapter.title}
          </h2>
          <div className="flex items-center space-x-4 text-sm text-smoke-gray">
            <span>{content.split(" ").filter(Boolean).length} words</span>
            <span>{content.length} characters</span>
            <span>{Math.ceil(content.split(" ").filter(Boolean).length / 250)} min read</span>
          </div>
        </div>
      )}

      {/* Floating Toolbar */}
      {showToolbar && (
        <EditorToolbar
          onClose={() => setShowToolbar(false)}
        />
      )}

      {/* Editor Area */}
      <div className={cn(
        "flex-1 overflow-auto",
        state.focusMode 
          ? "focus-mode px-8 py-12" 
          : "px-6 py-6"
      )}>
        <div
          ref={editorRef}
          contentEditable
          suppressContentEditableWarning
          className={cn(
            "min-h-full outline-none",
            "prose prose-invert prose-lg max-w-none",
            "prose-headings:text-white prose-headings:font-semibold",
            "prose-p:text-gray-300 prose-p:leading-relaxed",
            "prose-strong:text-white",
            "prose-em:text-gray-300",
            "focus:prose-p:text-white transition-colors",
            state.focusMode && "prose-xl",
            !content && "empty"
          )}
          style={{
            fontFamily: "Inter, sans-serif",
            fontSize: state.focusMode ? "20px" : "18px",
            lineHeight: "1.7",
          }}
          onInput={(e) => {
            const target = e.target as HTMLDivElement;
            handleContentChange(target.innerHTML);
          }}
          onMouseUp={handleSelection}
          onKeyUp={handleSelection}
          dangerouslySetInnerHTML={{ __html: content }}
        />
        
        {/* Placeholder */}
        {!content && (
          <div className="absolute top-20 left-6 pointer-events-none">
            <p className="text-smoke-gray text-lg">
              {state.focusMode 
                ? "Enter your story..." 
                : "Start writing your chapter..."}
            </p>
            <p className="text-smoke-gray/70 text-sm mt-2">
              Use "/" for commands, or just start typing
            </p>
          </div>
        )}
      </div>

      {/* Word count for focus mode */}
      {state.focusMode && content && (
        <div className="absolute bottom-6 right-6 bg-charcoal-black/80 backdrop-blur-sm rounded-lg px-4 py-2 text-sm text-smoke-gray">
          {content.split(" ").filter(Boolean).length} words
        </div>
      )}

      {/* Ambient particles for focus mode */}
      {state.focusMode && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="ember-particle absolute top-1/4 left-1/4"></div>
          <div className="ember-particle absolute top-1/3 right-1/3"></div>
          <div className="ember-particle absolute bottom-1/4 left-1/3"></div>
          <div className="ember-particle absolute bottom-1/3 right-1/4"></div>
        </div>
      )}
    </div>
  );
}
'''

# Properties panel (right panel)
properties_panel_tsx = '''"use client";

import { useState } from "react";
import { Chapter, Project } from "@/types";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import {
  Palette,
  Type,
  Layout,
  Sparkles,
  BarChart3,
  Settings,
} from "lucide-react";

interface PropertiesPanelProps {
  chapter: Chapter | null;
  project: Project;
}

export function PropertiesPanel({ chapter, project }: PropertiesPanelProps) {
  const [selectedFont, setSelectedFont] = useState("Inter");
  const [fontSize, setFontSize] = useState(16);

  return (
    <div className="bg-dark-forest border-l border-forest-teal/20 flex flex-col h-full">
      <div className="p-4 border-b border-forest-teal/20">
        <h2 className="font-semibold text-white flex items-center">
          <Settings className="h-4 w-4 mr-2 text-forest-teal" />
          Properties
        </h2>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-4">
        <Accordion type="multiple" defaultValue={["typography", "ai", "stats"]} className="space-y-2">
          {/* Typography Controls */}
          <AccordionItem value="typography" className="border border-forest-teal/20 rounded-lg">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <div className="flex items-center">
                <Type className="h-4 w-4 mr-2 text-warm-amber" />
                <span className="text-white">Typography</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="space-y-4">
                <div>
                  <Label className="text-smoke-gray">Font Family</Label>
                  <Select value={selectedFont} onValueChange={setSelectedFont}>
                    <SelectTrigger className="mt-1 bg-charcoal-black border-forest-teal/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Inter">Inter</SelectItem>
                      <SelectItem value="Georgia">Georgia</SelectItem>
                      <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                      <SelectItem value="Arial">Arial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-smoke-gray">Font Size</Label>
                  <div className="mt-1 flex items-center space-x-2">
                    <Input
                      type="number"
                      value={fontSize}
                      onChange={(e) => setFontSize(Number(e.target.value))}
                      className="w-20 bg-charcoal-black border-forest-teal/20"
                      min="12"
                      max="24"
                    />
                    <span className="text-smoke-gray text-sm">px</span>
                  </div>
                </div>

                <div>
                  <Label className="text-smoke-gray">Line Height</Label>
                  <Select defaultValue="1.6">
                    <SelectTrigger className="mt-1 bg-charcoal-black border-forest-teal/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1.4">1.4</SelectItem>
                      <SelectItem value="1.5">1.5</SelectItem>
                      <SelectItem value="1.6">1.6</SelectItem>
                      <SelectItem value="1.7">1.7</SelectItem>
                      <SelectItem value="1.8">1.8</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full border-neon-green/30 text-neon-green hover:bg-neon-green/10"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  AI Suggestions
                </Button>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* AI Assistant */}
          <AccordionItem value="ai" className="border border-forest-teal/20 rounded-lg">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <div className="flex items-center">
                <Sparkles className="h-4 w-4 mr-2 text-neon-green" />
                <span className="text-white">AI Assistant</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="space-y-3">
                <Card className="bg-charcoal-black/50 border-forest-teal/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-forest-teal">Writing Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="text-xs text-smoke-gray">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Readability</span>
                        <span className="text-neon-green">Good</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tone</span>
                        <span className="text-forest-teal">Professional</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Genre Match</span>
                        <span className="text-warm-amber">89%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Button 
                  variant="default" 
                  size="sm" 
                  className="w-full bg-neon-green hover:bg-neon-green/90 text-dark-forest"
                >
                  Analyze Content
                </Button>

                <div className="space-y-1">
                  <div className="text-xs text-smoke-gray">AI Suggestions:</div>
                  <div className="text-xs text-smoke-gray/70 space-y-1">
                    <p>• Consider shorter paragraphs</p>
                    <p>• Add more dialogue breaks</p>
                    <p>• Strengthen opening hook</p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Document Stats */}
          <AccordionItem value="stats" className="border border-forest-teal/20 rounded-lg">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <div className="flex items-center">
                <BarChart3 className="h-4 w-4 mr-2 text-ember-orange" />
                <span className="text-white">Statistics</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-charcoal-black/50 rounded-lg p-3">
                    <div className="text-smoke-gray">Words</div>
                    <div className="text-white font-medium">
                      {chapter?.content?.split(" ").filter(Boolean).length || 0}
                    </div>
                  </div>
                  <div className="bg-charcoal-black/50 rounded-lg p-3">
                    <div className="text-smoke-gray">Characters</div>
                    <div className="text-white font-medium">
                      {chapter?.content?.length || 0}
                    </div>
                  </div>
                  <div className="bg-charcoal-black/50 rounded-lg p-3">
                    <div className="text-smoke-gray">Paragraphs</div>
                    <div className="text-white font-medium">
                      {chapter?.content?.split("\n\n").filter(Boolean).length || 0}
                    </div>
                  </div>
                  <div className="bg-charcoal-black/50 rounded-lg p-3">
                    <div className="text-smoke-gray">Reading Time</div>
                    <div className="text-white font-medium">
                      {Math.ceil((chapter?.content?.split(" ").filter(Boolean).length || 0) / 250)} min
                    </div>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-smoke-gray">Chapter Progress</span>
                    <span className="text-forest-teal">
                      {Math.min(100, Math.round(((chapter?.content?.split(" ").filter(Boolean).length || 0) / 2000) * 100))}%
                    </span>
                  </div>
                  <Progress 
                    value={Math.min(100, Math.round(((chapter?.content?.split(" ").filter(Boolean).length || 0) / 2000) * 100))}
                    className="h-2"
                  />
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Export Settings */}
          <AccordionItem value="export" className="border border-forest-teal/20 rounded-lg">
            <AccordionTrigger className="px-4 py-3 hover:no-underline">
              <div className="flex items-center">
                <Layout className="h-4 w-4 mr-2 text-forest-teal" />
                <span className="text-white">Export</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="space-y-3">
                <Button variant="outline" size="sm" className="w-full">
                  Quick EPUB Export
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  Generate PDF
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  Create Cover
                </Button>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
}
'''

# Create additional UI components needed
accordion_tsx = '''import * as React from "react";
import * as AccordionPrimitive from "@radix-ui/react-accordion";
import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

const Accordion = AccordionPrimitive.Root;

const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    className={cn("border-b", className)}
    {...props}
  />
));
AccordionItem.displayName = "AccordionItem";

const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex">
    <AccordionPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex flex-1 items-center justify-between py-4 font-medium transition-all hover:underline [&[data-state=open]>svg]:rotate-180",
        className
      )}
      {...props}
    >
      {children}
      <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-200" />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
));
AccordionTrigger.displayName = AccordionPrimitive.Trigger.displayName;

const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    className="overflow-hidden text-sm transition-all data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down"
    {...props}
  >
    <div className={cn("pb-4 pt-0", className)}>{children}</div>
  </AccordionPrimitive.Content>
));

AccordionContent.displayName = AccordionPrimitive.Content.displayName;

export { Accordion, AccordionItem, AccordionTrigger, AccordionContent };
'''

select_tsx = '''import * as React from "react";
import * as SelectPrimitive from "@radix-ui/react-select";
import { Check, ChevronDown, ChevronUp } from "lucide-react";
import { cn } from "@/lib/utils";

const Select = SelectPrimitive.Root;

const SelectGroup = SelectPrimitive.Group;

const SelectValue = SelectPrimitive.Value;

const SelectTrigger = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Trigger
    ref={ref}
    className={cn(
      "flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className
    )}
    {...props}
  >
    {children}
    <SelectPrimitive.Icon asChild>
      <ChevronDown className="h-4 w-4 opacity-50" />
    </SelectPrimitive.Icon>
  </SelectPrimitive.Trigger>
));
SelectTrigger.displayName = SelectPrimitive.Trigger.displayName;

const SelectScrollUpButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollUpButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollUpButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollUpButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronUp className="h-4 w-4" />
  </SelectPrimitive.ScrollUpButton>
));
SelectScrollUpButton.displayName = SelectPrimitive.ScrollUpButton.displayName;

const SelectScrollDownButton = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.ScrollDownButton>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.ScrollDownButton>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.ScrollDownButton
    ref={ref}
    className={cn(
      "flex cursor-default items-center justify-center py-1",
      className
    )}
    {...props}
  >
    <ChevronDown className="h-4 w-4" />
  </SelectPrimitive.ScrollDownButton>
));
SelectScrollDownButton.displayName =
  SelectPrimitive.ScrollDownButton.displayName;

const SelectContent = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Content>
>(({ className, children, position = "popper", ...props }, ref) => (
  <SelectPrimitive.Portal>
    <SelectPrimitive.Content
      ref={ref}
      className={cn(
        "relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
        position === "popper" &&
          "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
        className
      )}
      position={position}
      {...props}
    >
      <SelectScrollUpButton />
      <SelectPrimitive.Viewport
        className={cn(
          "p-1",
          position === "popper" &&
            "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
        )}
      >
        {children}
      </SelectPrimitive.Viewport>
      <SelectScrollDownButton />
    </SelectPrimitive.Content>
  </SelectPrimitive.Portal>
));
SelectContent.displayName = SelectPrimitive.Content.displayName;

const SelectLabel = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Label>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Label>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Label
    ref={ref}
    className={cn("py-1.5 pl-8 pr-2 text-sm font-semibold", className)}
    {...props}
  />
));
SelectLabel.displayName = SelectPrimitive.Label.displayName;

const SelectItem = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Item>
>(({ className, children, ...props }, ref) => (
  <SelectPrimitive.Item
    ref={ref}
    className={cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    )}
    {...props}
  >
    <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
      <SelectPrimitive.ItemIndicator>
        <Check className="h-4 w-4" />
      </SelectPrimitive.ItemIndicator>
    </span>

    <SelectPrimitive.ItemText>{children}</SelectPrimitive.ItemText>
  </SelectPrimitive.Item>
));
SelectItem.displayName = SelectPrimitive.Item.displayName;

const SelectSeparator = React.forwardRef<
  React.ElementRef<typeof SelectPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof SelectPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <SelectPrimitive.Separator
    ref={ref}
    className={cn("-mx-1 my-1 h-px bg-muted", className)}
    {...props}
  />
));
SelectSeparator.displayName = SelectPrimitive.Separator.displayName;

export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
  SelectScrollUpButton,
  SelectScrollDownButton,
};
'''

# Editor toolbar component
editor_toolbar_tsx = '''"use client";

import { Button } from "@/components/ui/button";
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Link,
  Quote,
  X,
} from "lucide-react";

interface EditorToolbarProps {
  onClose: () => void;
}

export function EditorToolbar({ onClose }: EditorToolbarProps) {
  const handleFormat = (command: string, value?: string) => {
    document.execCommand(command, false, value);
  };

  return (
    <div className="absolute z-50 bg-charcoal-black border border-forest-teal/30 rounded-lg shadow-lg p-2 flex items-center space-x-1">
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("bold")}
      >
        <Bold className="h-4 w-4" />
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("italic")}
      >
        <Italic className="h-4 w-4" />
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("underline")}
      >
        <Underline className="h-4 w-4" />
      </Button>
      
      <div className="w-px h-6 bg-forest-teal/30" />
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("justifyLeft")}
      >
        <AlignLeft className="h-4 w-4" />
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("justifyCenter")}
      >
        <AlignCenter className="h-4 w-4" />
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("justifyRight")}
      >
        <AlignRight className="h-4 w-4" />
      </Button>
      
      <div className="w-px h-6 bg-forest-teal/30" />
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => {
          const url = prompt("Enter URL:");
          if (url) handleFormat("createLink", url);
        }}
      >
        <Link className="h-4 w-4" />
      </Button>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={() => handleFormat("formatBlock", "blockquote")}
      >
        <Quote className="h-4 w-4" />
      </Button>
      
      <div className="w-px h-6 bg-forest-teal/30" />
      
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 text-smoke-gray hover:text-white"
        onClick={onClose}
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
}
'''

# Create remaining editor and UI components
remaining_components = {
    "ezunder-complete/src/components/editor/navigation-panel.tsx": navigation_panel_tsx,
    "ezunder-complete/src/components/editor/editor-canvas.tsx": editor_canvas_tsx,
    "ezunder-complete/src/components/editor/properties-panel.tsx": properties_panel_tsx,
    "ezunder-complete/src/components/editor/editor-toolbar.tsx": editor_toolbar_tsx,
    "ezunder-complete/src/components/ui/accordion.tsx": accordion_tsx,
    "ezunder-complete/src/components/ui/select.tsx": select_tsx,
}

for file_path, content in remaining_components.items():
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, "w") as f:
        f.write(content)

print("✅ Remaining editor and UI components created:")
for file_path in remaining_components.keys():
    print(f"   📄 {file_path.split('/')[-1]}")