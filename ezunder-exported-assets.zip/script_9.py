# Create more shadcn/ui components that we need

# Avatar component
avatar_tsx = '''import * as React from "react";
import * as AvatarPrimitive from "@radix-ui/react-avatar";
import { cn } from "@/lib/utils";

const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    className={cn(
      "relative flex h-10 w-10 shrink-0 overflow-hidden rounded-full",
      className
    )}
    {...props}
  />
));
Avatar.displayName = AvatarPrimitive.Root.displayName;

const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    className={cn("aspect-square h-full w-full", className)}
    {...props}
  />
));
AvatarImage.displayName = AvatarPrimitive.Image.displayName;

const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    className={cn(
      "flex h-full w-full items-center justify-center rounded-full bg-muted",
      className
    )}
    {...props}
  />
));
AvatarFallback.displayName = AvatarPrimitive.Fallback.displayName;

export { Avatar, AvatarImage, AvatarFallback };
'''

# Sheet component
sheet_tsx = '''import * as React from "react";
import * as SheetPrimitive from "@radix-ui/react-dialog";
import { cva, type VariantProps } from "class-variance-authority";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

const Sheet = SheetPrimitive.Root;

const SheetTrigger = SheetPrimitive.Trigger;

const SheetClose = SheetPrimitive.Close;

const SheetPortal = SheetPrimitive.Portal;

const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Overlay
    className={cn(
      "fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    )}
    {...props}
    ref={ref}
  />
));
SheetOverlay.displayName = SheetPrimitive.Overlay.displayName;

const sheetVariants = cva(
  "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:duration-300 data-[state=open]:duration-500",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom:
          "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right:
          "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm",
      },
    },
    defaultVariants: {
      side: "right",
    },
  }
);

interface SheetContentProps
  extends React.ComponentPropsWithoutRef<typeof SheetPrimitive.Content>,
    VariantProps<typeof sheetVariants> {}

const SheetContent = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Content>,
  SheetContentProps
>(({ side = "right", className, children, ...props }, ref) => (
  <SheetPortal>
    <SheetOverlay />
    <SheetPrimitive.Content
      ref={ref}
      className={cn(sheetVariants({ side }), className)}
      {...props}
    >
      {children}
      <SheetPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary">
        <X className="h-4 w-4" />
        <span className="sr-only">Close</span>
      </SheetPrimitive.Close>
    </SheetPrimitive.Content>
  </SheetPortal>
));
SheetContent.displayName = SheetPrimitive.Content.displayName;

const SheetHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col space-y-2 text-center sm:text-left",
      className
    )}
    {...props}
  />
);
SheetHeader.displayName = "SheetHeader";

const SheetFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    )}
    {...props}
  />
);
SheetFooter.displayName = "SheetFooter";

const SheetTitle = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Title>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Title
    ref={ref}
    className={cn("text-lg font-semibold text-foreground", className)}
    {...props}
  />
));
SheetTitle.displayName = SheetPrimitive.Title.displayName;

const SheetDescription = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Description>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
));
SheetDescription.displayName = SheetPrimitive.Description.displayName;

export {
  Sheet,
  SheetPortal,
  SheetOverlay,
  SheetTrigger,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetFooter,
  SheetTitle,
  SheetDescription,
};
'''

# Progress component
progress_tsx = '''import * as React from "react";
import * as ProgressPrimitive from "@radix-ui/react-progress";
import { cn } from "@/lib/utils";

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>
>(({ className, value, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn(
      "relative h-2 w-full overflow-hidden rounded-full bg-secondary",
      className
    )}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className="h-full w-full flex-1 bg-neon-green transition-all"
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
));
Progress.displayName = ProgressPrimitive.Root.displayName;

export { Progress };
'''

# Label component
label_tsx = '''import * as React from "react";
import * as LabelPrimitive from "@radix-ui/react-label";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);

const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root> &
    VariantProps<typeof labelVariants>
>(({ className, ...props }, ref) => (
  <LabelPrimitive.Root
    ref={ref}
    className={cn(labelVariants(), className)}
    {...props}
  />
));
Label.displayName = LabelPrimitive.Root.displayName;

export { Label };
'''

# Create additional UI components
additional_ui_components = {
    "ezunder-complete/src/components/ui/avatar.tsx": avatar_tsx,
    "ezunder-complete/src/components/ui/sheet.tsx": sheet_tsx,
    "ezunder-complete/src/components/ui/progress.tsx": progress_tsx,
    "ezunder-complete/src/components/ui/label.tsx": label_tsx,
}

for file_path, content in additional_ui_components.items():
    with open(file_path, "w") as f:
        f.write(content)

print("✅ Additional shadcn/ui components created:")
for file_path in additional_ui_components.keys():
    print(f"   📄 {file_path.split('/')[-1]}")

# Create types definition file
types_ts = '''// TypeScript type definitions for eZunder
export interface User {
  id: string;
  email: string;
  name?: string;
  image?: string;
  subscriptionTier: "free" | "professional" | "enterprise";
  createdAt: Date;
  updatedAt: Date;
}

export interface Project {
  id: string;
  title: string;
  author?: string;
  description?: string;
  genre?: string;
  coverImage?: string;
  content?: string;
  contentAnalysis?: ContentAnalysis;
  aiRecommendations?: AIRecommendations;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  chapters?: Chapter[];
}

export interface Chapter {
  id: string;
  title: string;
  content?: string;
  orderIndex: number;
  projectId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ContentAnalysis {
  genre: {
    primaryGenre: string;
    subGenre?: string;
    confidence: number;
    themes: string[];
    mood: string;
    targetAudience: string;
  };
  style: {
    averageSentenceLength: number;
    vocabularyComplexity: string;
    toneAnalysis: string;
    readingLevel: string;
  };
  readability: {
    gradeLevel: number;
    readingEase: number;
    avgWordsPerSentence: number;
  };
  grammar: {
    overallScore: number;
    errors: GrammarError[];
  };
}

export interface GrammarError {
  type: "grammar" | "style" | "punctuation" | "spelling";
  text: string;
  suggestion: string;
  explanation?: string;
  position: {
    start: number;
    end: number;
  };
}

export interface AIRecommendations {
  typography: {
    heading: TypographySettings;
    body: TypographySettings;
    accent?: TypographySettings;
  };
  layout: {
    margins: string;
    spacing: string;
    alignment: string;
  };
  suggestions: string[];
}

export interface TypographySettings {
  font: string;
  size: string;
  weight?: string;
  lineHeight?: string;
  confidence?: number;
}

export interface FontRecommendation {
  heading: {
    family: string;
    weight: string;
    size: string;
    confidence: number;
  };
  body: {
    family: string;
    weight: string;
    size: string;
    lineHeight: string;
    confidence: number;
  };
  accent?: {
    family: string;
    usage: string;
    confidence: number;
  };
  pairingRationale: string;
}

export interface CoverDesign {
  imageUrl: string;
  style: {
    name: string;
    description: string;
  };
  designElements: {
    colorPalette: string[];
    typography: string;
  };
  confidence: number;
}

export interface ExportFormat {
  name: string;
  description: string;
  extension: string;
  supported: boolean;
  options?: Record<string, any>;
}

export interface AiAnalysis {
  id: string;
  projectId: string;
  analysisType: string;
  results: any;
  confidenceScore: number;
  createdAt: Date;
}

export interface NavItem {
  title: string;
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
  variant?: "default" | "neon";
  disabled?: boolean;
}

export interface DashboardConfig {
  mainNav: NavItem[];
  sidebarNav: NavItem[];
}

// Editor specific types
export interface EditorState {
  content: string;
  selection: {
    start: number;
    end: number;
  };
  focusMode: boolean;
  previewMode: "none" | "split" | "full";
  activePanel: "navigation" | "editor" | "properties";
}

export interface EditorTools {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  alignment: "left" | "center" | "right" | "justify";
  fontSize: number;
  fontFamily: string;
}

export interface ProjectStats {
  wordCount: number;
  characterCount: number;
  pageCount: number;
  readingTime: number;
  chaptersCount: number;
}
'''

with open("ezunder-complete/src/types/index.ts", "w") as f:
    f.write(types_ts)

print("✅ TypeScript types definition created")